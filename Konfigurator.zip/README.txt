Opis procesu instalacji skryptu na stronie internetowej:
1.Plik index.php skopiowa? do folderu strony (b?d? je?li konfigurator ma by? tylko cz??ci? ju? istniej?cej witryny - skopiowa? zawarto?? index.php do swojej strony)
nale?y pami?ta? aby pozosta?e foldery i pliki z katalogu znajdowa?y si? w tym samym folderze
2. Zaimportowa? do pliku strony wszystkie pliki z katologu css oraz js 
3. Zawarty w g?ownym katalogu plik tabeli bazy danych - parts.php zaimportowa? do ju? istniej?cej bazy, lub stworzy? now? (jest ona potrzebna do obs?ugi panelu administratorskiego)
4. Utworzy? konto u?ytkownia z dost?pem do tabeli parts i jego dane logowania zapisa? w pliku db_conn.php, ktory znajduje si? w folderze php_files.
5. Aby teraz wej?? na panel administratorski nale?y otworzy? w przegl?darce plik admin.php, czyli do paska adresu dopisa? /admin.php.
6(opcjonalnie). Aby zmieni? has?o o ktore jest si? proszonym przy wej?ciu na panel nale?y otworzy? i zeedytowa? plik pass.php w folderze php_files.

W razie jakichkolwiek dodatkowych problemow prosz? o kontakt na j.rajca45@gmail.com 