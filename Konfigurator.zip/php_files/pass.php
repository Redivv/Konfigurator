<?php
  $pass = "admin"; // hasło do panelu
?>
